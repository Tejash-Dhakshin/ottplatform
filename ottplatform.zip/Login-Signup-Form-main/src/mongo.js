const mongoose=require("mongoose")
mongoose.set('strictQuery', true)
mongoose.connect("mongodb://127.0.0.1:27017/newott").then(()=>{
    console.log("db connected");
})
.catch(()=>{
    console.log("db failed");
})


const loginschema=new mongoose.Schema({
    
        name:{
            type:String,
            required:true
        },
        password:{
            type:String,
            required:true
        }
})

const collection=new mongoose.model("users",loginschema)

module.exports=collection